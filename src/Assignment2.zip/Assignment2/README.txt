Name: Jett Anderson Lab F 2-3:30
EID: jra2995
Main Method: BankDriver.java
Analysis: EE422CLab2_jra2995.pdf
Design: EE422CLab2_jra2995.pdf
I have input prompts separately for ID #, Customer Name, 
Customer Address, Transaction Type, Amount, Account Type 1, and Account Type 2,
in that order, followed by result of transaction and then prompt to ask to continue.
At the end, will be a summary for each customer's bank accounts.